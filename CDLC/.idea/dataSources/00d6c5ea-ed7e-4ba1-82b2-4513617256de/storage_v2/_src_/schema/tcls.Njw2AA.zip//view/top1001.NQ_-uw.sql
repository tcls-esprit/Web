create view top1001 as
select `tcls`.`product`.`id` AS `id`,`tcls`.`product`.`name` AS `name`,`tcls`.`product`.`price` AS `price`
from `tcls`.`product`
order by `tcls`.`product`.`price`;

