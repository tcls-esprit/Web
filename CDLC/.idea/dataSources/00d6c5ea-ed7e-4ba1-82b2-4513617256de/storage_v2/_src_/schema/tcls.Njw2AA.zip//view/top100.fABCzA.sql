create view top100 as
select `tcls`.`product`.`id` AS `id`,`tcls`.`product`.`name` AS `name`,`tcls`.`product`.`price` AS `price`
from `tcls`.`product`
having (count(`tcls`.`product`.`id`) < 4)
order by `tcls`.`product`.`price`;

